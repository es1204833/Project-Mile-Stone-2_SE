package repository;

import static org.junit.Assert.*;

import org.junit.Test;

public class TextBookRepositoryTest {

	@Test
	public void testGetTextBooks() {
		fail("Not yet implemented");
	}

	@Test
	public void testAddTextBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testUpdateTextBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testDeleteTextBook() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTextBook() {
		fail("Not yet implemented");
	}

}
