/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;



import Repository.TextBookRepository;
import static com.sun.corba.se.spi.presentation.rmi.StubAdapter.request;
import java.io.IOException;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Textbook;

/**
 *
 * @author HP
 */
@WebServlet("/ModifyNumberOfCopies")
public class ModifyNumberOfCopiesController extends HttpServlet {
    
    @Inject
    TextBookRepository textRepository;
    
     protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        

        request.getRequestDispatcher("ModifyNumberOfCopies.jsp").forward(request, response);
    }
     
     @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {

            Textbook textbook = new Textbook();
            //task.setFromAya(Integer.parseInt(request.getParameter("fromAya")));
            //task.setToAya(Integer.parseInt(request.getParameter("toAya")));
            //task.setDueDate(DateUtils.toDate(request.getParameter("dueDate")));
            textbook.setIsbn(Integer.parseInt(request.getParameter("isbn")));
            textbook.setMaleNumOfCopies(Integer.parseInt(request.getParameter("maleNumOfCopies")));
            textbook.setFemaleNumOfCopies(Integer.parseInt(request.getParameter("femaleNumOfCopies")));
            textbook.setInstructorNumOfCopies(Integer.parseInt(request.getParameter("instructorNumOfCopies")));


            //task.setSurah(surahRepository.getSurah(Integer.parseInt(request.getParameter("sura"))));

            //User user = (User) request.getSession().getAttribute("user");
            //taskRepository.addTask(user.getId(), task);

            //Store a confirmation message
            request.getSession().setAttribute("message", "Task created successfully!");
            response.sendRedirect("pending");
        } catch (Exception ex) {
            ex.printStackTrace(response.getWriter());
        }
    }

    //</editor-fold>
    
}
