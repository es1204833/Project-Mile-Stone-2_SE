/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import Model.CourseCoordinator;
import Repository.CourseCoordinatorRepository;
import java.io.IOException;
import javax.inject.Inject;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author HP
 */
@WebServlet("/login")
public class loginController extends HttpServlet {
    
     @Inject
    CourseCoordinatorRepository courseCoordinatorRepository;
   
    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.getRequestDispatcher("login.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        CourseCoordinator courseCoordinator = courseCoordinatorRepository.getCourseCoordinator((String) request.getParameter("username"), (String) request.getParameter("password"));

        if (courseCoordinator == null) {
            request.setAttribute("message", "Username and/or Password incorrect! please try again");
            request.getRequestDispatcher("login.jsp").forward(request, response);
        } else {
            request.getSession().setAttribute("courseCoordinator", courseCoordinator);
            response.sendRedirect("addtextbook");
        }
    }

    
}
