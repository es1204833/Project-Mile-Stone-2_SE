package model;

public class Semester {

	private String semesterRange;
	
	public Semester() {
	}

	public Semester(String semesterRange) {
		this.semesterRange = semesterRange;
	}

	public String getSemesterRange() {
		return semesterRange;
	}

	public void setSemesterRange(String semesterRange) {
		this.semesterRange = semesterRange;
	}
	
	
}
