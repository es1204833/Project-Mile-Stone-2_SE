package Repository;

import Model.CourseCoordinator;
import com.google.gson.Gson;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.Singleton;
import java.util.Optional;

@Singleton
public class CourseCoordinatorRepository {

    private List<CourseCoordinator> courseCoordinators;
    private int lastUserId = 0;
    private final String usersUrl = "http://erradi.github.io/users.js";

    public List<CourseCoordinator> getCoursecoordinators() {
        if (courseCoordinators != null) {
            return courseCoordinators;
        } else {
            loadCourseCoordinators();
            return courseCoordinators;
        }
    }

    public CourseCoordinator addCourseCoordinator(CourseCoordinator courseCoordinator) {
        if (courseCoordinators == null) {
            courseCoordinators = new ArrayList();
        }
        courseCoordinators.add(courseCoordinator);
        courseCoordinator.setId(++lastUserId);
        return courseCoordinator;
    }

    public void updateCourseCoordinator(CourseCoordinator courseCoordinator) {
        for (int i = 0; i < courseCoordinators.size(); i++) {
            if (courseCoordinators.get(i).getId() == courseCoordinator.getId()) {
                courseCoordinators.set(i, courseCoordinator);
                break;
            }
        }
    }

    

    public CourseCoordinator getCourseCoordinator(int id) {
        if (courseCoordinators == null) {
            loadCourseCoordinators();
        }
        return courseCoordinators.stream().filter(c -> c.getId() == id).findFirst().get();
    }

    public int getCourseCoordinatorsCount() {
        return courseCoordinators == null ? 0 : courseCoordinators.size();
    }

    public void loadCourseCoordinators() {
        if (courseCoordinators != null && courseCoordinators.size() > 0) {
            return;
        }

        Gson gson = new Gson();
        String courseCoordinatorsStr = Utils.readUrl(usersUrl);
        System.out.println(courseCoordinatorsStr);

        CourseCoordinator[] courseCoordinatorArray = gson.fromJson(courseCoordinatorsStr, CourseCoordinator[].class);
        courseCoordinators = new ArrayList<>(Arrays.asList(courseCoordinatorArray));
        lastUserId = courseCoordinators.size();
    }

    public CourseCoordinator getCourseCoordinator(String username, String password) {
        if (courseCoordinators == null) {
            loadCourseCoordinators();
        }
        Optional<CourseCoordinator> courseCoordinator = courseCoordinators.stream().filter(c -> c.getUsername().equals(username) && c.getPassword().equals(password)).findFirst();

        return courseCoordinator.isPresent() ? courseCoordinator.get() : null;
    }

}