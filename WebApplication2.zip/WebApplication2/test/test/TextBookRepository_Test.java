package test;

import Repository.TextBookRepository;
import static org.junit.Assert.*;

import java.util.List;

import model.Textbook;

import org.junit.Test;



public class TextBookRepository_Test {
	
	public List<Textbook> textbooks;
	TextBookRepository TBR1 = new TextBookRepository(null , 1111);

	@Test
	public void testGetTextBooks() {
		TBR1.getTextBooks();
		assertEquals(null,TBR1.getTextBook(0));
		
	}

	@Test
	public void testGetTextBook() {
		TBR1.getTextBooks();
		assertEquals(null,TBR1.getTextBook(0));
	}
	
	@Test
	public void testInsertTestData() {
		TBR1.insertTestData();
		assertEquals(null,TBR1.getTextBook(0));
	}

	@Test
	public void testGetStatus() {
		assertEquals("Available", TBR1.getStatuss());
	}
	
	@Test
	public void testAddTextBook() {
		TBR1.addTextBook(new Textbook(978, "C++ Without Fear", "Brian Overlan",
				2004, "Dean & Deka ,United States", 8, false, "Avilable", 80,
				"12/5/2006"));
		
		System.out.println("Added");
	}

	@Test
	public void testUpdateTextBook() {
		TBR1.addTextBook(new Textbook(977, "C++ Without Fear", "Brian Overlan",
				2004, "Dean & Deka ,United States", 8, false, "Avilable", 80,
				"12/5/2006"));
		System.out.println("Updated");
	}

}
